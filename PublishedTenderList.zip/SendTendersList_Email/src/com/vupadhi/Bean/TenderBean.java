package com.vupadhi.Bean;

public class TenderBean {
	
	private String nTenderID;
	private String sTenderNo;
	private String sNameOfWork;
	private String sDepartment;
	private String sCircleDivisionName;
	private String dtPreBidOpeningDate;
	private String bidSubmissionStartDate;
	private String dtBidSubmissionClosingDate;
	public String getnTenderID() {
		return nTenderID;
	}
	public void setnTenderID(String nTenderID) {
		this.nTenderID = nTenderID;
	}
	public String getsTenderNo() {
		return sTenderNo;
	}
	public void setsTenderNo(String sTenderNo) {
		this.sTenderNo = sTenderNo;
	}
	public String getsNameOfWork() {
		return sNameOfWork;
	}
	public void setsNameOfWork(String sNameOfWork) {
		this.sNameOfWork = sNameOfWork;
	}
	public String getsDepartment() {
		return sDepartment;
	}
	public void setsDepartment(String sDepartment) {
		this.sDepartment = sDepartment;
	}
	public String getsCircleDivisionName() {
		return sCircleDivisionName;
	}
	public void setsCircleDivisionName(String sCircleDivisionName) {
		this.sCircleDivisionName = sCircleDivisionName;
	}
	public String getDtPreBidOpeningDate() {
		return dtPreBidOpeningDate;
	}
	public void setDtPreBidOpeningDate(String dtPreBidOpeningDate) {
		this.dtPreBidOpeningDate = dtPreBidOpeningDate;
	}
	public String getBidSubmissionStartDate() {
		return bidSubmissionStartDate;
	}
	public void setBidSubmissionStartDate(String bidSubmissionStartDate) {
		this.bidSubmissionStartDate = bidSubmissionStartDate;
	}
	public String getDtBidSubmissionClosingDate() {
		return dtBidSubmissionClosingDate;
	}
	public void setDtBidSubmissionClosingDate(String dtBidSubmissionClosingDate) {
		this.dtBidSubmissionClosingDate = dtBidSubmissionClosingDate;
	}
	
	
}
