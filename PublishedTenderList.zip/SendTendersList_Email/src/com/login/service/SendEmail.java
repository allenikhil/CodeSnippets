package com.login.service;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.mail.BodyPart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;

import com.vupadhi.Bean.TenderBean;

public class SendEmail {

	static Session session;
	private static final String EMAIL_FROM = "nikhil.a@vupadhi.com";
	//private static final String EMAIL_CC= "kiran.kumar@vupadhi.com,tssupport.mngr@vupadhi.com";
	private static final String EMAIL_TO = "nikhil.a@vupadhi.com";

	private static final String EMAIL_SUBJECT = "Tender Publishing report day wise based on key words";

	public static void main(String[] args) {

		Properties props = new Properties();

		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.host", "send.one.com");

		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.debug", "true");

		// creating session object to get properties
		session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("nikhil.a@vupadhi.com", "Vupadhi12345");
			}
		});
		try {
			sendEmail();
		} catch (ClassNotFoundException | SQLException | ParseException e) {
			e.printStackTrace();
		}
	}

	public static void sendEmail() throws SQLException, ClassNotFoundException, ParseException {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		String userName = "Dev_Team";
		String password = "pass@word1";
		String url = "jdbc:sqlserver://192.168.0.10\\MSDB;databaseName=APTMS_DEV";
		Connection con = DriverManager.getConnection(url, userName, password);
		Statement s1 = con.createStatement();

		LocalDate date = LocalDate.now();
		System.out.println("one day before current date is " + date.minusDays(1).toString());

		String publishedDate = date.minusDays(1).toString();


		ResultSet results = s1.executeQuery(
				" SELECT [nTenderID],[sTenderNo],[sNameOfWork],[sDepartment],[sCircleDivisionName],CONVERT(varchar(10),[dtPreBidOpeningDate],101) + right(CONVERT(varchar(32),[dtPreBidOpeningDate],100),8) AS [dtPreBidOpeningDate],CONVERT(varchar(10),[dtTenderOpeningDate],101) + right(convert(varchar(32),[dtTenderOpeningDate],100),8) AS dtTenderOpeningDate, CONVERT(varchar(10),[dtBidSubmissionClosingDate],101) + right(convert(varchar(32),[dtBidSubmissionClosingDate],100),8) AS [dtBidSubmissionClosingDate] FROM tbltender t "
				+ "JOIN dbo.Split('E-procurement Software,Website Development Service,Development software,System Integrator,e-learning Software,Procurement Software,Priced EOI,unPriced EOI,it enable,estamp, electronic stamp,portal Management,citizen service"
				+ " ,Training,computer education,computer training,it training,operation & maintenance,Implementation,migration,skill development,RFQ, NCB, ICB, EoI, expression of interest',',') s ON (t.sNameOfWork LIKE N'%'+s.Items+'%' OR [t].[sTypeOfWork] LIKE N'%'+s.Items+'%' OR [t].[sTenderSubject] LIKE N'%'+s.Items+'%')\r\n" + 
				"where datediff(day, dtPublishedDate,'"+ publishedDate + "') = 0 ");
		Map<String, TenderBean> list = new LinkedHashMap<String, TenderBean>();

		if (results != null) {
			while (results.next()) {
						TenderBean bean = new TenderBean();
						bean.setnTenderID(results.getString("nTenderID"));
						bean.setsTenderNo(results.getString("sTenderNo"));
						bean.setsNameOfWork(results.getString("sNameOfWork"));
						bean.setsDepartment(results.getString("sDepartment"));
						bean.setsCircleDivisionName(results.getString("sCircleDivisionName"));
						if(results.getString("dtPreBidOpeningDate")==null)
						{
							bean.setDtPreBidOpeningDate("N/A");
						}
						else
						{
							bean.setDtPreBidOpeningDate(results.getString("dtPreBidOpeningDate"));	
						}
						bean.setBidSubmissionStartDate(results.getString("dtTenderOpeningDate"));
						bean.setDtBidSubmissionClosingDate(results.getString("dtBidSubmissionClosingDate"));
						list.put(results.getString("nTenderID"), bean);
			}
		}
		System.out.println(list);
		System.out.println(list.size());

		try {
			Message msg = new MimeMessage(session);

			msg.setFrom(new InternetAddress(EMAIL_FROM));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(EMAIL_TO));
		//	msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse(EMAIL_CC));

			msg.setSubject(EMAIL_SUBJECT);

			final StringBuilder sb = new StringBuilder();
			sb.append("<h3><FONT face='MS Sans Serif' color='Blue'>Published Tender List </FONT></h3><br/> <br/>");
			sb.append("<table cellpadding='3' cellspacing='0' width='100%' border='1'>");
			sb.append("<FONT face='MS Sans Serif' size=3>");
			sb.append("<tr>");
			sb.append("<td><font color='Blue' font-weight='bold'>Sl.No&nbsp</font></td>");
			sb.append("<td><font color='Blue' font-weight='bold'>Tender ID</font></td>");
			sb.append("<td><font color='Blue' font-weight='bold'>Tender No</font></td>");
			sb.append("<td><font color='Blue' font-weight='bold'>Name Of Work</font></td>");
			sb.append("<td><font color='Blue' font-weight='bold'>Department</font></td>");
			sb.append("<td><font color='Blue' font-weight='bold'>Circle</font></td>");
			sb.append("<td><font color='Blue' font-weight='bold'>Pre-bid Meeting Date</font></td>");
			sb.append("<td><font color='Blue' font-weight='bold'>Bid Submission Start Date</font></td>");
			sb.append("<td><font color='Blue' font-weight='bold'>Bid Submission Closing Date</font></td>");

			int size = 1;
			for (Map.Entry<String, TenderBean> entry : list.entrySet()) {
				sb.append("<tr>");
				sb.append("<td>" + size + " </td>");
				sb.append("<td>" + entry.getValue().getnTenderID() + " </td>");
				sb.append("<td>" + entry.getValue().getsTenderNo() + " </td>");
				sb.append("<td>" + entry.getValue().getsNameOfWork() + " </td>");
				sb.append("<td>" + entry.getValue().getsDepartment() + " </td>");
				sb.append("<td>" + entry.getValue().getsCircleDivisionName() + " </td>");
				sb.append("<td>" + entry.getValue().getDtPreBidOpeningDate() + "</td>");
				sb.append("<td>" + entry.getValue().getBidSubmissionStartDate() + "</td>");
				sb.append("<td>" + entry.getValue().getDtBidSubmissionClosingDate() + "</td>");
				sb.append("</tr>");
				size++;
			}
			sb.append("</FONT>");
			sb.append("</table>");
			sb.append("<br/><br/>");
			sb.toString();

			String htmlText = sb.toString();
			MimeMultipart multipart = new MimeMultipart("related");
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(messageBodyPart);

			msg.setContent(multipart);
//            Transport.send(msg);
			System.out.println("Send");

		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
}